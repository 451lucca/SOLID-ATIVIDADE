package com.labagenda.domain;

public enum TransferStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
