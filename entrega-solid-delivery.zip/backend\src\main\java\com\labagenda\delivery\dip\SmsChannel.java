package com.labagenda.delivery.dip;

import java.util.Objects;

public class SmsChannel extends AbstractNotificationChannel {

    private final String senderId;

    public SmsChannel(String senderId) {
        String trimmed = Objects.requireNonNull(senderId, "senderId").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("senderId cannot be blank");
        }
        this.senderId = trimmed;
    }

    public String getSenderId() {
        return senderId;
    }

    @Override
    public String getChannelName() {
        return "SMS";
    }
}
