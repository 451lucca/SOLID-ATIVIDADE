package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.Objects;

public class Pizza extends Product {

    private final String flavor;
    private final String size;

    public Pizza(String flavor, String size, BigDecimal price) {
        super("Pizza " + requireText(flavor, "flavor"), price);
        this.flavor = requireText(flavor, "flavor");
        this.size = requireText(size, "size");
    }

    public String getFlavor() {
        return flavor;
    }

    public String getSize() {
        return size;
    }

    @Override
    public String getCategory() {
        return "Pizza";
    }

    private static String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
