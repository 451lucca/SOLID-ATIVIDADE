package com.labagenda.delivery.ocp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

public class PaymentReceipt {

    private final String paymentMethod;
    private final BigDecimal amount;
    private final String confirmationCode;
    private final LocalDateTime processedAt;

    public PaymentReceipt(String paymentMethod, BigDecimal amount, String confirmationCode, LocalDateTime processedAt) {
        this.paymentMethod = requireText(paymentMethod, "paymentMethod");
        this.amount = Objects.requireNonNull(amount, "amount");
        this.confirmationCode = requireText(confirmationCode, "confirmationCode");
        this.processedAt = Objects.requireNonNull(processedAt, "processedAt");
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getConfirmationCode() {
        return confirmationCode;
    }

    public LocalDateTime getProcessedAt() {
        return processedAt;
    }

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
