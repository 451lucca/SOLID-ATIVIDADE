package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryOrderRepositoryTest {

    @Test
    void storesAndRetrievesOrderById() {
        InMemoryOrderRepository repository = new InMemoryOrderRepository();
        Order order = new Order(
            "order-1",
            "Joao",
            Collections.singletonList(new OrderItem("Hamburguer", 1, new BigDecimal("32.90"))),
            new BigDecimal("32.90"),
            LocalDateTime.of(2026, 5, 18, 10, 30)
        );

        repository.save(order);

        assertTrue(repository.findById("order-1").isPresent());
        assertEquals(order, repository.findById("order-1").get());
        assertEquals(1, repository.findAll().size());
    }
}
