package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class OrderFactoryTest {

    @Test
    void createsOrderWithGeneratedIdAndCalculatedTotal() {
        OrderFactory factory = new OrderFactory();
        Order order = factory.create("Maria", Arrays.asList(
            new OrderItem("Pizza Calabresa", 1, new BigDecimal("45.00")),
            new OrderItem("Suco", 2, new BigDecimal("8.50"))
        ));

        assertNotNull(order.getId());
        assertFalse(order.getId().trim().isEmpty());
        assertEquals("Maria", order.getCustomerName());
        assertEquals(new BigDecimal("62.00"), order.getTotal());
        assertEquals(2, order.getItems().size());
    }
}
