package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.Objects;

public class Hamburguer extends Product {

    private final String protein;
    private final boolean doubleCheese;

    public Hamburguer(String protein, boolean doubleCheese, BigDecimal price) {
        super("Hamburguer " + requireText(protein, "protein"), price);
        this.protein = requireText(protein, "protein");
        this.doubleCheese = doubleCheese;
    }

    public String getProtein() {
        return protein;
    }

    public boolean isDoubleCheese() {
        return doubleCheese;
    }

    @Override
    public String getCategory() {
        return "Hamburguer";
    }

    private static String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
