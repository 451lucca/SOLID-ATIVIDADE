package com.labagenda.delivery.dip;

public interface NotificationChannel {

    String getChannelName();

    void send(String recipient, String message);
}
