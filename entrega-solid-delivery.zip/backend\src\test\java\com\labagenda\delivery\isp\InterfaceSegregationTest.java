package com.labagenda.delivery.isp;

import com.labagenda.delivery.srp.Order;
import com.labagenda.delivery.srp.OrderItem;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InterfaceSegregationTest {

    @Test
    void notificationSenderOnlyImplementsNotificationResponsibilities() {
        MemoryNotificationSender sender = new MemoryNotificationSender();

        sender.send("cliente@exemplo.com", "Pedido pronto");

        assertEquals("cliente@exemplo.com", sender.getLastRecipient());
        assertEquals("Pedido pronto", sender.getLastMessage());
    }

    @Test
    void orderAndDeliveryManagersHandleOnlyTheirOwnResponsibilities() {
        InMemoryOrderManager orderManager = new InMemoryOrderManager();
        InMemoryDeliveryManager deliveryManager = new InMemoryDeliveryManager();

        Order order = new Order(
            "order-isp",
            "Paulo",
            Collections.singletonList(new OrderItem("Pizza", 1, new BigDecimal("55.00"))),
            new BigDecimal("55.00"),
            LocalDateTime.of(2026, 5, 18, 12, 0)
        );

        orderManager.register(order);
        deliveryManager.schedule(order.getId(), "Rua Central, 100");

        SummaryReportGenerator reportGenerator = new SummaryReportGenerator(orderManager, deliveryManager);

        assertEquals(1, orderManager.listOrders().size());
        assertEquals("SCHEDULED", deliveryManager.getStatus(order.getId()));
        assertEquals("Rua Central, 100", deliveryManager.getAddress(order.getId()));
        assertTrue(reportGenerator.generate().contains("Orders: 1"));
        assertTrue(reportGenerator.generate().contains("deliveries: 1"));
    }
}
