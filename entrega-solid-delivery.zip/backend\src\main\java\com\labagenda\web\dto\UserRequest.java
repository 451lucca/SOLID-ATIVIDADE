package com.labagenda.web.dto;

import com.labagenda.domain.UserRole;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class UserRequest {

    @NotBlank(message = "não pode ficar em branco")
    private String fullName;

    @Email(message = "deve ser um email válido")
    @NotBlank(message = "não pode ficar em branco")
    private String email;

    @NotNull(message = "é obrigatório")
    private UserRole role = UserRole.USER;

    private Boolean active = true;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}
