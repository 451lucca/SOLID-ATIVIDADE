package com.labagenda.bootstrap;

import com.labagenda.domain.AppUser;
import com.labagenda.domain.Laboratory;
import com.labagenda.domain.Reservation;
import com.labagenda.domain.ReservationStatus;
import com.labagenda.domain.TransferRequest;
import com.labagenda.domain.TransferStatus;
import com.labagenda.domain.UserRole;
import com.labagenda.repository.AppUserRepository;
import com.labagenda.repository.LaboratoryRepository;
import com.labagenda.repository.ReservationRepository;
import com.labagenda.repository.TransferRequestRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Component
@Transactional
public class DataSeeder implements CommandLineRunner {

    private final AppUserRepository userRepository;
    private final LaboratoryRepository laboratoryRepository;
    private final ReservationRepository reservationRepository;
    private final TransferRequestRepository transferRequestRepository;

    public DataSeeder(AppUserRepository userRepository,
                      LaboratoryRepository laboratoryRepository,
                      ReservationRepository reservationRepository,
                      TransferRequestRepository transferRequestRepository) {
        this.userRepository = userRepository;
        this.laboratoryRepository = laboratoryRepository;
        this.reservationRepository = reservationRepository;
        this.transferRequestRepository = transferRequestRepository;
    }

    @Override
    public void run(String... args) {
        AppUser ana = ensureUser("Ana Souza", "ana@lab.local", UserRole.ADMIN);
        AppUser bruno = ensureUser("Bruno Lima", "bruno@lab.local", UserRole.USER);
        AppUser carla = ensureUser("Carla Mendes", "carla@lab.local", UserRole.USER);

        Laboratory bioquimica = ensureLab(
                "Laboratório de Bioquímica",
                "Espaço para análises químicas e preparações de amostras.",
                "Bloco A, sala 204",
                18,
                "Centrífuga, espectrofotômetro, balanças analíticas"
        );

        Laboratory hematologia = ensureLab(
                "Laboratório de Hematologia",
                "Área equipada para contagem celular e exames hematológicos.",
                "Bloco B, sala 108",
                14,
                "Microscópios, pipetas automáticas, agitadores"
        );

        if (reservationRepository.count() == 0) {
            Reservation first = new Reservation();
            first.setLaboratory(bioquimica);
            first.setReservedBy(ana);
            first.setTitle("Amostras de rotina");
            first.setPurpose("Rotina de validação de reagentes.");
            first.setStartAt(slot(1, 9));
            first.setEndAt(slot(1, 11));
            first.setStatus(ReservationStatus.SCHEDULED);
            first.setNotes("Reserva inicial para demonstração.");
            reservationRepository.save(first);

            Reservation second = new Reservation();
            second.setLaboratory(hematologia);
            second.setReservedBy(bruno);
            second.setTitle("Treinamento interno");
            second.setPurpose("Capacitação da equipe para equipamentos novos.");
            second.setStartAt(slot(1, 14));
            second.setEndAt(slot(1, 16));
            second.setStatus(ReservationStatus.SCHEDULED);
            second.setNotes("Sala com 4 microscópios disponíveis.");
            reservationRepository.save(second);
        }

        if (transferRequestRepository.count() == 0 && reservationRepository.count() > 0) {
            Reservation seededReservation = reservationRepository.findAll().get(0);
            TransferRequest transferRequest = new TransferRequest();
            transferRequest.setReservation(seededReservation);
            transferRequest.setRequestedBy(seededReservation.getReservedBy());
            transferRequest.setTargetUser(carla);
            transferRequest.setMessage("Preciso transferir esta reserva para outro turno.");
            transferRequest.setStatus(TransferStatus.PENDING);
            transferRequestRepository.save(transferRequest);
        }
    }

    private AppUser ensureUser(String fullName, String email, UserRole role) {
        return userRepository.findByEmailIgnoreCase(email).orElseGet(() -> {
            AppUser user = new AppUser();
            user.setFullName(fullName);
            user.setEmail(email);
            user.setRole(role);
            user.setActive(true);
            return userRepository.save(user);
        });
    }

    private Laboratory ensureLab(String name, String description, String location, Integer capacity, String equipment) {
        return laboratoryRepository.findAll().stream()
                .filter(laboratory -> name.equalsIgnoreCase(laboratory.getName()))
                .findFirst()
                .orElseGet(() -> {
                    Laboratory laboratory = new Laboratory();
                    laboratory.setName(name);
                    laboratory.setDescription(description);
                    laboratory.setLocation(location);
                    laboratory.setCapacity(capacity);
                    laboratory.setEquipment(equipment);
                    laboratory.setActive(true);
                    return laboratoryRepository.save(laboratory);
                });
    }

    private LocalDateTime slot(int dayOffset, int hour) {
        return LocalDateTime.now()
                .plusDays(dayOffset)
                .withHour(hour)
                .withMinute(0)
                .withSecond(0)
                .withNano(0);
    }
}
