package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class OrderFormatter {

    public String format(Order order) {
        StringBuilder builder = new StringBuilder();
        builder.append("Order ").append(order.getId()).append(System.lineSeparator());
        builder.append("Customer: ").append(order.getCustomerName()).append(System.lineSeparator());
        builder.append("Items:").append(System.lineSeparator());

        List<OrderItem> items = order.getItems();
        for (OrderItem item : items) {
            builder.append("- ")
                   .append(item.getProductName())
                   .append(" x")
                   .append(item.getQuantity())
                   .append(" = ")
                   .append(formatMoney(item.getSubtotal()))
                   .append(System.lineSeparator());
        }

        builder.append("Total: ").append(formatMoney(order.getTotal())).append(System.lineSeparator());
        builder.append("Created at: ").append(order.getCreatedAt());
        return builder.toString();
    }

    private String formatMoney(BigDecimal value) {
        return "R$ " + value.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }
}
