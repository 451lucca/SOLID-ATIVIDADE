package com.labagenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabAgendaApplication {

    public static void main(String[] args) {
        SpringApplication.run(LabAgendaApplication.class, args);
    }
}
