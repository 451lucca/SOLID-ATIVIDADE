package com.labagenda.delivery.isp;

public class SummaryReportGenerator implements ReportGenerator {

    private final OrderManager orderManager;
    private final DeliveryManager deliveryManager;

    public SummaryReportGenerator(OrderManager orderManager, DeliveryManager deliveryManager) {
        this.orderManager = orderManager;
        this.deliveryManager = deliveryManager;
    }

    @Override
    public String generate() {
        return "Orders: " + orderManager.listOrders().size()
            + ", deliveries: " + deliveryManager.countScheduled();
    }
}
