package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Order {

    private final String id;
    private final String customerName;
    private final List<OrderItem> items;
    private final BigDecimal total;
    private final LocalDateTime createdAt;

    public Order(String id, String customerName, List<OrderItem> items, BigDecimal total, LocalDateTime createdAt) {
        this.id = requireText(id, "id");
        this.customerName = requireText(customerName, "customerName");
        this.items = Collections.unmodifiableList(new ArrayList<OrderItem>(Objects.requireNonNull(items, "items")));
        if (this.items.isEmpty()) {
            throw new IllegalArgumentException("items cannot be empty");
        }
        this.total = Objects.requireNonNull(total, "total");
        if (total.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("total cannot be negative");
        }
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt");
    }

    public String getId() {
        return id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
