package com.labagenda.delivery.ocp;

import java.math.BigDecimal;
import java.util.Objects;

public class CheckoutService {

    public PaymentReceipt process(BigDecimal amount, PaymentMethod paymentMethod) {
        Objects.requireNonNull(paymentMethod, "paymentMethod");
        return paymentMethod.pay(amount);
    }
}
