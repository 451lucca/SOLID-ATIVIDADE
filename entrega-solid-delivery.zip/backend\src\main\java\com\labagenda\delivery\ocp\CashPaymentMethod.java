package com.labagenda.delivery.ocp;

import java.util.Objects;

public class CashPaymentMethod extends AbstractPaymentMethod {

    private final String cashierName;

    public CashPaymentMethod(String cashierName) {
        String trimmed = Objects.requireNonNull(cashierName, "cashierName").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("cashierName cannot be blank");
        }
        this.cashierName = trimmed;
    }

    public String getCashierName() {
        return cashierName;
    }

    @Override
    public String getMethodName() {
        return "Cash";
    }
}
