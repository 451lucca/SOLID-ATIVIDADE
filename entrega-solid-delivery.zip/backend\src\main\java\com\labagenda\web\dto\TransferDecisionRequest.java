package com.labagenda.web.dto;

import javax.validation.constraints.NotNull;

public class TransferDecisionRequest {

    @NotNull(message = "é obrigatório")
    private Long approverUserId;

    private String reason;

    public Long getApproverUserId() {
        return approverUserId;
    }

    public void setApproverUserId(Long approverUserId) {
        this.approverUserId = approverUserId;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
