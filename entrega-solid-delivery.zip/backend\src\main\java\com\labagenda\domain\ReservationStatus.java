package com.labagenda.domain;

public enum ReservationStatus {
    SCHEDULED,
    CANCELLED,
    COMPLETED,
    TRANSFERRED
}
