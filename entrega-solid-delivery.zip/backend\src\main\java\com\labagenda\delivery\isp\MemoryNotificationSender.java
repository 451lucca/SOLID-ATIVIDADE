package com.labagenda.delivery.isp;

import java.util.Objects;

public class MemoryNotificationSender implements NotificationSender {

    private String lastRecipient;
    private String lastMessage;

    @Override
    public void send(String recipient, String message) {
        this.lastRecipient = requireText(recipient, "recipient");
        this.lastMessage = requireText(message, "message");
    }

    public String getLastRecipient() {
        return lastRecipient;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
