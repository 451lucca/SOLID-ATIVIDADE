package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MenuTotalCalculatorTest {

    @Test
    void acceptsAnyProductSubtypeWithoutBreakingBehavior() {
        List<Product> products = Arrays.<Product>asList(
            new Pizza("Calabresa", "Grande", new BigDecimal("58.00")),
            new Hamburguer("Bovina", true, new BigDecimal("34.90")),
            new Bebida("Refrigerante", 350, new BigDecimal("8.50"))
        );

        MenuTotalCalculator calculator = new MenuTotalCalculator();

        assertEquals(new BigDecimal("101.40"), calculator.calculateTotal(products));
        assertTrue(products.get(0).describe().contains("Pizza"));
        assertTrue(products.get(1).describe().contains("Hamburguer"));
        assertTrue(products.get(2).describe().contains("Bebida"));
    }
}
