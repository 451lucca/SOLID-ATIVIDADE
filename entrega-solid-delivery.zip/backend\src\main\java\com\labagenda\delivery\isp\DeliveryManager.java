package com.labagenda.delivery.isp;

public interface DeliveryManager {

    void schedule(String orderId, String address);

    String getStatus(String orderId);

    int countScheduled();
}
