package com.labagenda.repository;

import com.labagenda.domain.TransferRequest;
import com.labagenda.domain.TransferStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransferRequestRepository extends JpaRepository<TransferRequest, Long> {
    List<TransferRequest> findByStatusOrderByCreatedAtDesc(TransferStatus status);

    List<TransferRequest> findByTargetUserIdOrderByCreatedAtDesc(Long targetUserId);

    boolean existsByReservationIdAndTargetUserIdAndStatus(Long reservationId, Long targetUserId, TransferStatus status);

    long countByRequestedById(Long requestedById);

    long countByTargetUserId(Long targetUserId);

    void deleteByReservationId(Long reservationId);
}
