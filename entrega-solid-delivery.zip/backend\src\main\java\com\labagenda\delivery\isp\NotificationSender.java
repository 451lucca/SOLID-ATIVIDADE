package com.labagenda.delivery.isp;

public interface NotificationSender {

    void send(String recipient, String message);
}
