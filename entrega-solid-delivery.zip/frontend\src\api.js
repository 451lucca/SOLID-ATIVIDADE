const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });

  if (response.status === 204) {
    return null;
  }

  const text = await response.text();
  let payload = null;

  if (text) {
    try {
      payload = JSON.parse(text);
    } catch (error) {
      payload = text;
    }
  }

  if (!response.ok) {
    const message = payload && typeof payload === 'object' && payload.message
      ? payload.message
      : `Requisição falhou (${response.status})`;
    throw new Error(message);
  }

  return payload;
}

function jsonOptions(method, body) {
  return {
    method,
    body: JSON.stringify(body)
  };
}

export const api = {
  getUsers: () => request('/users'),
  createUser: (body) => request('/users', jsonOptions('POST', body)),
  updateUser: (id, body) => request(`/users/${id}`, jsonOptions('PUT', body)),
  deleteUser: (id) => request(`/users/${id}`, { method: 'DELETE' }),

  getLabs: () => request('/laboratories'),
  createLab: (body) => request('/laboratories', jsonOptions('POST', body)),
  updateLab: (id, body) => request(`/laboratories/${id}`, jsonOptions('PUT', body)),
  deleteLab: (id) => request(`/laboratories/${id}`, { method: 'DELETE' }),

  getReservations: () => request('/reservations'),
  createReservation: (body) => request('/reservations', jsonOptions('POST', body)),
  updateReservation: (id, body) => request(`/reservations/${id}`, jsonOptions('PUT', body)),
  deleteReservation: (id) => request(`/reservations/${id}`, { method: 'DELETE' }),
  cancelReservation: (id) => request(`/reservations/${id}/cancel`, { method: 'POST' }),

  getTransfers: () => request('/transfers'),
  createTransfer: (body) => request('/transfers', jsonOptions('POST', body)),
  approveTransfer: (id, body) => request(`/transfers/${id}/approve`, jsonOptions('POST', body)),
  rejectTransfer: (id, body) => request(`/transfers/${id}/reject`, jsonOptions('POST', body))
};
