package com.labagenda.delivery.ocp;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class CheckoutServiceTest {

    @Test
    void processesCardPayment() {
        assertReceipt(new CardPaymentMethod("Maria"), "Card");
    }

    @Test
    void processesPixPayment() {
        assertReceipt(new PixPaymentMethod("maria@pix.com"), "PIX");
    }

    @Test
    void processesCashPayment() {
        assertReceipt(new CashPaymentMethod("Carlos"), "Cash");
    }

    @Test
    void acceptsNewPaymentTypesWithoutChangingCheckoutService() {
        CheckoutService service = new CheckoutService();

        PaymentReceipt receipt = service.process(new BigDecimal("15.00"), new PaymentMethod() {
            @Override
            public String getMethodName() {
                return "Voucher";
            }

            @Override
            public PaymentReceipt pay(BigDecimal amount) {
                return new PaymentReceipt(getMethodName(), amount, "voucher-" + new Date().getTime(), java.time.LocalDateTime.now());
            }
        });

        assertEquals("Voucher", receipt.getPaymentMethod());
        assertEquals(new BigDecimal("15.00"), receipt.getAmount());
        assertNotNull(receipt.getConfirmationCode());
    }

    private void assertReceipt(PaymentMethod paymentMethod, String expectedMethodName) {
        PaymentReceipt receipt = new CheckoutService().process(new BigDecimal("49.90"), paymentMethod);

        assertEquals(expectedMethodName, receipt.getPaymentMethod());
        assertEquals(new BigDecimal("49.90"), receipt.getAmount());
        assertNotNull(receipt.getConfirmationCode());
    }
}
