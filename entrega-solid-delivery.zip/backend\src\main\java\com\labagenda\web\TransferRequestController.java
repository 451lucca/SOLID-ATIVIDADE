package com.labagenda.web;

import com.labagenda.domain.TransferRequest;
import com.labagenda.domain.TransferStatus;
import com.labagenda.service.TransferRequestService;
import com.labagenda.web.dto.TransferDecisionRequest;
import com.labagenda.web.dto.TransferRequestRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/transfers")
@Validated
public class TransferRequestController {

    private final TransferRequestService transferRequestService;

    public TransferRequestController(TransferRequestService transferRequestService) {
        this.transferRequestService = transferRequestService;
    }

    @GetMapping
    public List<TransferRequest> list(@RequestParam(required = false) TransferStatus status) {
        return transferRequestService.list(status);
    }

    @GetMapping("/{id}")
    public TransferRequest get(@PathVariable Long id) {
        return transferRequestService.get(id);
    }

    @PostMapping
    public ResponseEntity<TransferRequest> create(@Valid @RequestBody TransferRequestRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(transferRequestService.create(request));
    }

    @PostMapping("/{id}/approve")
    public TransferRequest approve(@PathVariable Long id, @Valid @RequestBody TransferDecisionRequest request) {
        return transferRequestService.approve(id, request);
    }

    @PostMapping("/{id}/reject")
    public TransferRequest reject(@PathVariable Long id, @Valid @RequestBody TransferDecisionRequest request) {
        return transferRequestService.reject(id, request);
    }
}
