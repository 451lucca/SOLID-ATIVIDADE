import { useEffect, useMemo, useState } from 'react';
import { api } from './api';

const emptyUserForm = {
  fullName: '',
  email: '',
  role: 'USER',
  active: true
};

const emptyLabForm = {
  name: '',
  description: '',
  location: '',
  capacity: '1',
  equipment: '',
  active: true
};

const emptyReservationForm = {
  laboratoryId: '',
  reservedById: '',
  title: '',
  purpose: '',
  startAt: '',
  endAt: '',
  status: 'SCHEDULED',
  notes: ''
};

const emptyTransferForm = {
  reservationId: '',
  requestedById: '',
  targetUserId: '',
  message: ''
};

const tabs = [
  { id: 'dashboard', label: 'Painel' },
  { id: 'users', label: 'Usuários' },
  { id: 'labs', label: 'Laboratórios' },
  { id: 'reservations', label: 'Reservas' },
  { id: 'transfers', label: 'Trocas' }
];

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [users, setUsers] = useState([]);
  const [labs, setLabs] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [activeUserId, setActiveUserId] = useState('');

  const [userForm, setUserForm] = useState(emptyUserForm);
  const [labForm, setLabForm] = useState(emptyLabForm);
  const [reservationForm, setReservationForm] = useState(emptyReservationForm);
  const [transferForm, setTransferForm] = useState(emptyTransferForm);

  const [editingUserId, setEditingUserId] = useState(null);
  const [editingLabId, setEditingLabId] = useState(null);
  const [editingReservationId, setEditingReservationId] = useState(null);

  useEffect(() => {
    refreshAll();
  }, []);

  useEffect(() => {
    if (notice) {
      const timer = window.setTimeout(() => setNotice(''), 3200);
      return () => window.clearTimeout(timer);
    }
    return undefined;
  }, [notice]);

  useEffect(() => {
    if (!activeUserId && users.length > 0) {
      setActiveUserId(String(users[0].id));
    }
  }, [activeUserId, users]);

  const activeUser = useMemo(
    () => users.find((user) => String(user.id) === String(activeUserId)),
    [activeUserId, users]
  );

  const stats = useMemo(() => {
    return {
      users: users.length,
      labs: labs.length,
      reservations: reservations.length,
      pendingTransfers: transfers.filter((transfer) => transfer.status === 'PENDING').length
    };
  }, [labs, reservations, transfers, users]);

  const upcomingReservations = useMemo(() => {
    return [...reservations]
      .filter((reservation) => reservation.status !== 'CANCELLED')
      .slice(0, 5);
  }, [reservations]);

  async function refreshAll() {
    setLoading(true);
    setError('');
    try {
      const [loadedUsers, loadedLabs, loadedReservations, loadedTransfers] = await Promise.all([
        api.getUsers(),
        api.getLabs(),
        api.getReservations(),
        api.getTransfers()
      ]);
      setUsers(loadedUsers || []);
      setLabs(loadedLabs || []);
      setReservations(loadedReservations || []);
      setTransfers(loadedTransfers || []);
      if (loadedUsers && loadedUsers.length > 0) {
        setActiveUserId((current) => {
          if (current && loadedUsers.some((user) => String(user.id) === String(current))) {
            return current;
          }
          return String(loadedUsers[0].id);
-+        });
      } else {
        setActiveUserId('');
      }
    } catch (err) {
      setError(err.message || 'Não foi possível carregar os dados.');
    } finally {
      setLoading(false);
    }
  }

  function showNotice(message) {
    setNotice(message);
  }

  function startNewUser() {
    setEditingUserId(null);
    setUserForm(emptyUserForm);
  }

  function startEditUser(user) {
    setEditingUserId(user.id);
    setUserForm({
      fullName: user.fullName || '',
      email: user.email || '',
      role: user.role || 'USER',
      active: Boolean(user.active)
    });
    setActiveTab('users');
  }

  function startNewLab() {
    setEditingLabId(null);
    setLabForm(emptyLabForm);
  }

  function startEditLab(lab) {
    setEditingLabId(lab.id);
    setLabForm({
      name: lab.name || '',
      description: lab.description || '',
      location: lab.location || '',
      capacity: String(lab.capacity ?? '1'),
      equipment: lab.equipment || '',
      active: Boolean(lab.active)
    });
    setActiveTab('labs');
  }

  function startNewReservation() {
    setEditingReservationId(null);
    setReservationForm({
      ...emptyReservationForm,
      reservedById: activeUserId || (users[0] ? String(users[0].id) : ''),
      laboratoryId: labs[0] ? String(labs[0].id) : ''
    });
  }

  function startEditReservation(reservation) {
    setEditingReservationId(reservation.id);
    setReservationForm({
      laboratoryId: reservation.laboratory ? String(reservation.laboratory.id) : '',
      reservedById: reservation.reservedBy ? String(reservation.reservedBy.id) : '',
      title: reservation.title || '',
      purpose: reservation.purpose || '',
      startAt: toInputDateTime(reservation.startAt),
      endAt: toInputDateTime(reservation.endAt),
      status: reservation.status || 'SCHEDULED',
      notes: reservation.notes || ''
    });
    setActiveTab('reservations');
  }

  function startNewTransfer() {
    setTransferForm({
      ...emptyTransferForm,
      requestedById: activeUserId || (users[0] ? String(users[0].id) : ''),
      reservationId: reservations[0] ? String(reservations[0].id) : '',
      targetUserId: ''
    });
  }

  function prepareTransferFromReservation(reservation) {
    const requesterId = reservation.reservedBy ? String(reservation.reservedBy.id) : '';
    const availableTarget = users.find((user) => String(user.id) !== requesterId);
    setTransferForm({
      reservationId: String(reservation.id),
      requestedById: requesterId,
      targetUserId: availableTarget ? String(availableTarget.id) : '',
      message: `Solicitação de troca da reserva "${reservation.title}"`
    });
    setActiveTab('transfers');
  }

  async function saveUser(event) {
    event.preventDefault();
    try {
      const payload = {
        fullName: userForm.fullName,
        email: userForm.email,
        role: userForm.role,
        active: Boolean(userForm.active)
      };
      if (editingUserId) {
        await api.updateUser(editingUserId, payload);
        showNotice('Usuário atualizado com sucesso.');
      } else {
        await api.createUser(payload);
        showNotice('Usuário criado com sucesso.');
      }
      startNewUser();
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteUser(id) {
    if (!window.confirm('Tem certeza que deseja excluir este usuário?')) {
      return;
    }
    try {
      await api.deleteUser(id);
      showNotice('Usuário removido.');
      if (String(activeUserId) === String(id)) {
        setActiveUserId('');
      }
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function saveLab(event) {
    event.preventDefault();
    try {
      const payload = {
        name: labForm.name,
        description: labForm.description,
        location: labForm.location,
        capacity: Number(labForm.capacity || 1),
        equipment: labForm.equipment,
        active: Boolean(labForm.active)
      };
      if (editingLabId) {
        await api.updateLab(editingLabId, payload);
        showNotice('Laboratório atualizado com sucesso.');
      } else {
        await api.createLab(payload);
        showNotice('Laboratório criado com sucesso.');
      }
      startNewLab();
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteLab(id) {
    if (!window.confirm('Tem certeza que deseja excluir este laboratório?')) {
      return;
    }
    try {
      await api.deleteLab(id);
      showNotice('Laboratório removido.');
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function saveReservation(event) {
    event.preventDefault();
    try {
      const payload = {
        laboratoryId: Number(reservationForm.laboratoryId),
        reservedById: Number(reservationForm.reservedById),
        title: reservationForm.title,
        purpose: reservationForm.purpose,
        startAt: reservationForm.startAt,
        endAt: reservationForm.endAt,
        status: reservationForm.status,
        notes: reservationForm.notes
      };
      if (editingReservationId) {
        await api.updateReservation(editingReservationId, payload);
        showNotice('Reserva atualizada com sucesso.');
      } else {
        await api.createReservation(payload);
        showNotice('Reserva criada com sucesso.');
      }
      startNewReservation();
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function deleteReservation(id) {
    if (!window.confirm('Tem certeza que deseja excluir esta reserva?')) {
      return;
    }
    try {
      await api.deleteReservation(id);
      showNotice('Reserva removida.');
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function cancelReservation(id) {
    try {
      await api.cancelReservation(id);
      showNotice('Reserva cancelada.');
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function saveTransfer(event) {
    event.preventDefault();
    try {
      const payload = {
        reservationId: Number(transferForm.reservationId),
        requestedById: Number(transferForm.requestedById),
        targetUserId: Number(transferForm.targetUserId),
        message: transferForm.message
      };
      await api.createTransfer(payload);
      showNotice('Solicitação de troca criada.');
      setTransferForm(emptyTransferForm);
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function approveTransfer(id, targetUserId) {
    try {
      await api.approveTransfer(id, {
        approverUserId: Number(activeUserId || targetUserId),
        reason: 'Aprovado pelo usuário alvo.'
      });
      showNotice('Solicitação aprovada.');
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function rejectTransfer(id, targetUserId) {
    const reason = window.prompt('Informe o motivo da rejeição', 'Sem disponibilidade no momento.') || '';
    try {
      await api.rejectTransfer(id, {
        approverUserId: Number(activeUserId || targetUserId),
        reason
      });
      showNotice('Solicitação rejeitada.');
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="app-shell">
      <div className="ambient ambient-left" />
      <div className="ambient ambient-right" />

      <header className="hero">
        <div>
          <p className="eyebrow">Agenda e reserva de laboratórios</p>
          <h1>Sistema de CRUD com troca autorizada de reservas</h1>
          <p className="hero-copy">
            Gerencie usuários, laboratórios e reservas. Quando alguém quiser transferir uma reserva,
            o usuário alvo precisa aprovar a solicitação dentro do sistema.
          </p>
        </div>

        <div className="hero-panel">
          <label className="field">
            <span>Usuário ativo</span>
            <select value={activeUserId} onChange={(event) => setActiveUserId(event.target.value)}>
              <option value="">Selecione</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.fullName}
                </option>
              ))}
            </select>
          </label>
          <div className="chip-row">
            <span className="chip">{activeUser ? activeUser.fullName : 'Nenhum usuário selecionado'}</span>
            <button className="ghost-button" type="button" onClick={refreshAll}>
              Recarregar
            </button>
          </div>
        </div>
      </header>

      <nav className="tab-bar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={activeTab === tab.id ? 'tab active' : 'tab'}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      {(notice || error) && (
        <div className="alerts">
          {notice && <div className="alert success">{notice}</div>}
          {error && <div className="alert error">{error}</div>}
        </div>
      )}

      {loading ? (
        <div className="loading-card">Carregando dados da agenda...</div>
      ) : (
        <>
          {activeTab === 'dashboard' && (
            <div className="dashboard-grid">
              <section className="card stat-grid">
                <StatCard label="Usuários" value={stats.users} tone="blue" />
                <StatCard label="Laboratórios" value={stats.labs} tone="teal" />
                <StatCard label="Reservas" value={stats.reservations} tone="amber" />
                <StatCard label="Trocas pendentes" value={stats.pendingTransfers} tone="violet" />
              </section>

              <section className="card">
                <SectionTitle
                  title="Próximas reservas"
                  subtitle="Uma visão rápida das próximas ocupações do laboratório."
                />
                <div className="mini-list">
                  {upcomingReservations.length === 0 ? (
                    <p className="empty-text">Nenhuma reserva cadastrada ainda.</p>
                  ) : (
                    upcomingReservations.map((reservation) => (
                      <article key={reservation.id} className="mini-item">
                        <div>
                          <strong>{reservation.title}</strong>
                          <p>
                            {reservation.laboratory ? reservation.laboratory.name : 'Laboratório'}
                            {' · '}
                            {reservation.reservedBy ? reservation.reservedBy.fullName : 'Usuário'}
                          </p>
                        </div>
                        <span className={`status-pill ${statusClass(reservation.status)}`}>
                          {reservation.status}
                        </span>
                      </article>
                    ))
                  )}
                </div>
              </section>

              <section className="card">
                <SectionTitle
                  title="Fluxo de troca"
                  subtitle="O usuário solicitante cria o pedido e o usuário alvo decide aprovar ou rejeitar."
                />
                <div className="flow">
                  <div className="flow-step">
                    <span className="flow-index">1</span>
                    <p>Crie a reserva do laboratório para um usuário.</p>
                  </div>
                  <div className="flow-step">
                    <span className="flow-index">2</span>
                    <p>Abra a aba de trocas e envie a solicitação para outro usuário.</p>
                  </div>
                  <div className="flow-step">
                    <span className="flow-index">3</span>
                    <p>Somente o usuário alvo pode aprovar a transferência.</p>
                  </div>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="split-layout">
              <section className="card">
                <div className="section-header">
                  <SectionTitle title="Usuários" subtitle="Cadastre quem pode reservar e aprovar trocas." />
                  <div className="section-actions">
                    <button className="ghost-button" type="button" onClick={startNewUser}>
                      Novo usuário
                    </button>
                  </div>
                </div>
                <SimpleTable
                  rows={users}
                  columns={[
                    { label: 'Nome', render: (row) => row.fullName },
                    { label: 'Email', render: (row) => row.email },
                    { label: 'Perfil', render: (row) => row.role },
                    {
                      label: 'Status',
                      render: (row) => <span className={`status-pill ${row.active ? 'ok' : 'off'}`}>{row.active ? 'Ativo' : 'Inativo'}</span>
                    }
                  ]}
                  onEdit={startEditUser}
                  onDelete={deleteUser}
                />
              </section>

              <section className="card">
                <SectionTitle
                  title={editingUserId ? 'Editar usuário' : 'Novo usuário'}
                  subtitle="Os dados são validados e o email precisa ser único."
                />
                <EntityForm
                  fields={[
                    { name: 'fullName', label: 'Nome completo', type: 'text', required: true },
                    { name: 'email', label: 'Email', type: 'email', required: true },
                    {
                      name: 'role',
                      label: 'Perfil',
                      type: 'select',
                      options: [
                        { label: 'Administrador', value: 'ADMIN' },
                        { label: 'Usuário', value: 'USER' }
                      ]
                    },
                    { name: 'active', label: 'Ativo', type: 'checkbox' }
                  ]}
                  values={userForm}
                  onChange={(name, value) => setUserForm((current) => ({ ...current, [name]: value }))}
                  onSubmit={saveUser}
                  submitLabel={editingUserId ? 'Salvar alterações' : 'Criar usuário'}
                  onReset={startNewUser}
                />
              </section>
            </div>
          )}

          {activeTab === 'labs' && (
            <div className="split-layout">
              <section className="card">
                <div className="section-header">
                  <SectionTitle
                    title="Laboratórios"
                    subtitle="Cadastre os espaços físicos que podem ser reservados."
                  />
                  <div className="section-actions">
                    <button className="ghost-button" type="button" onClick={startNewLab}>
                      Novo laboratório
                    </button>
                  </div>
                </div>
                <SimpleTable
                  rows={labs}
                  columns={[
                    { label: 'Nome', render: (row) => row.name },
                    { label: 'Local', render: (row) => row.location },
                    { label: 'Capacidade', render: (row) => row.capacity },
                    {
                      label: 'Status',
                      render: (row) => <span className={`status-pill ${row.active ? 'ok' : 'off'}`}>{row.active ? 'Ativo' : 'Inativo'}</span>
                    }
                  ]}
                  onEdit={startEditLab}
                  onDelete={deleteLab}
                />
              </section>

              <section className="card">
                <SectionTitle
                  title={editingLabId ? 'Editar laboratório' : 'Novo laboratório'}
                  subtitle="Use esse cadastro para controlar disponibilidade e capacidade."
                />
                <EntityForm
                  fields={[
                    { name: 'name', label: 'Nome', type: 'text', required: true },
                    { name: 'location', label: 'Local', type: 'text', required: true },
                    { name: 'capacity', label: 'Capacidade', type: 'number', required: true },
                    { name: 'description', label: 'Descrição', type: 'textarea' },
                    { name: 'equipment', label: 'Equipamentos', type: 'textarea' },
                    { name: 'active', label: 'Ativo', type: 'checkbox' }
                  ]}
                  values={labForm}
                  onChange={(name, value) => setLabForm((current) => ({ ...current, [name]: value }))}
                  onSubmit={saveLab}
                  submitLabel={editingLabId ? 'Salvar alterações' : 'Criar laboratório'}
                  onReset={startNewLab}
                />
              </section>
            </div>
          )}

          {activeTab === 'reservations' && (
            <div className="split-layout">
              <section className="card">
                <div className="section-header">
                  <SectionTitle
                    title="Reservas"
                    subtitle="Cada reserva liga um usuário a um laboratório em um horário específico."
                  />
                  <div className="section-actions">
                    <button className="ghost-button" type="button" onClick={startNewReservation}>
                      Nova reserva
                    </button>
                  </div>
                </div>
                <SimpleTable
                  rows={reservations}
                  columns={[
                    { label: 'Título', render: (row) => row.title },
                    { label: 'Laboratório', render: (row) => row.laboratory ? row.laboratory.name : '-' },
                    { label: 'Usuário', render: (row) => row.reservedBy ? row.reservedBy.fullName : '-' },
                    {
                      label: 'Período',
                      render: (row) => (
                        <span className="mono">
                          {formatDateTime(row.startAt)} até {formatDateTime(row.endAt)}
                        </span>
                      )
                    },
                    {
                      label: 'Status',
                      render: (row) => <span className={`status-pill ${statusClass(row.status)}`}>{row.status}</span>
                    }
                  ]}
                  onEdit={startEditReservation}
                  onDelete={deleteReservation}
                  extraActions={(row) => (
                    <>
                      <button className="inline-button" type="button" onClick={() => cancelReservation(row.id)}>
                        Cancelar
                      </button>
                      <button className="inline-button" type="button" onClick={() => prepareTransferFromReservation(row)}>
                        Solicitar troca
                      </button>
                    </>
                  )}
                />
              </section>

              <section className="card">
                <SectionTitle
                  title={editingReservationId ? 'Editar reserva' : 'Nova reserva'}
                  subtitle="A validação evita choques de horário no mesmo laboratório."
                />
                <EntityForm
                  fields={[
                    {
                      name: 'laboratoryId',
                      label: 'Laboratório',
                      type: 'select',
                      required: true,
                      options: labs.map((lab) => ({ label: lab.name, value: String(lab.id) }))
                    },
                    {
                      name: 'reservedById',
                      label: 'Usuário',
                      type: 'select',
                      required: true,
                      options: users.map((user) => ({ label: user.fullName, value: String(user.id) }))
                    },
                    { name: 'title', label: 'Título', type: 'text', required: true },
                    { name: 'purpose', label: 'Finalidade', type: 'textarea' },
                    { name: 'startAt', label: 'Início', type: 'datetime-local', required: true },
                    { name: 'endAt', label: 'Fim', type: 'datetime-local', required: true },
                    {
                      name: 'status',
                      label: 'Status',
                      type: 'select',
                      options: [
                        { label: 'Agendada', value: 'SCHEDULED' },
                        { label: 'Cancelada', value: 'CANCELLED' },
                        { label: 'Concluída', value: 'COMPLETED' },
                        { label: 'Transferida', value: 'TRANSFERRED' }
                      ]
                    },
                    { name: 'notes', label: 'Observações', type: 'textarea' }
                  ]}
                  values={reservationForm}
                  onChange={(name, value) => setReservationForm((current) => ({ ...current, [name]: value }))}
                  onSubmit={saveReservation}
                  submitLabel={editingReservationId ? 'Salvar alterações' : 'Criar reserva'}
                  onReset={startNewReservation}
                />
              </section>
            </div>
          )}

          {activeTab === 'transfers' && (
            <div className="split-layout">
              <section className="card">
                <SectionTitle
                  title="Solicitação de troca"
                  subtitle="O solicitante escolhe a reserva e o usuário alvo precisa aprovar a transferência."
                />
                <EntityForm
                  fields={[
                    {
                      name: 'reservationId',
                      label: 'Reserva',
                      type: 'select',
                      required: true,
                      options: reservations.map((reservation) => ({
                        label: `${reservation.title} - ${reservation.laboratory ? reservation.laboratory.name : 'Laboratório'}`,
                        value: String(reservation.id)
                      }))
                    },
                    {
                      name: 'requestedById',
                      label: 'Solicitante',
                      type: 'select',
                      required: true,
                      options: users.map((user) => ({ label: user.fullName, value: String(user.id) }))
                    },
                    {
                      name: 'targetUserId',
                      label: 'Usuário alvo',
                      type: 'select',
                      required: true,
                      options: users.map((user) => ({ label: user.fullName, value: String(user.id) }))
                    },
                    { name: 'message', label: 'Mensagem', type: 'textarea' }
                  ]}
                  values={transferForm}
                  onChange={(name, value) => setTransferForm((current) => ({ ...current, [name]: value }))}
                  onSubmit={saveTransfer}
                  submitLabel="Criar solicitação"
                  onReset={startNewTransfer}
                />
              </section>

              <section className="card">
                <SectionTitle
                  title="Pendente de aprovação"
                  subtitle="Somente o usuário alvo da solicitação pode decidir aprovar ou rejeitar."
                />
                <div className="transfer-list">
                  {transfers.length === 0 ? (
                    <p className="empty-text">Nenhuma solicitação de troca criada.</p>
                  ) : (
                    transfers.map((transfer) => {
                      const targetUser = transfer.targetUser;
                      const isPending = transfer.status === 'PENDING';
                      const canDecide =
                        isPending && targetUser && String(targetUser.id) === String(activeUserId);

                      return (
                        <article key={transfer.id} className="transfer-card">
                          <div className="transfer-header">
                            <div>
                              <strong>{transfer.reservation ? transfer.reservation.title : 'Reserva'}</strong>
                              <p>
                                {transfer.requestedBy ? transfer.requestedBy.fullName : 'Solicitante'} {'→ '}
                                {targetUser ? targetUser.fullName : 'Usuário alvo'}
                              </p>
                            </div>
                            <span className={`status-pill ${statusClass(transfer.status)}`}>{transfer.status}</span>
                          </div>

                          <p className="transfer-message">
                            {transfer.message || 'Sem mensagem adicional.'}
                          </p>

                          <p className="transfer-meta">
                            Criado em {formatDateTime(transfer.createdAt)}
                            {transfer.decidedAt ? ` · Decidido em ${formatDateTime(transfer.decidedAt)}` : ''}
                          </p>

                          {transfer.decisionReason && (
                            <p className="transfer-meta">Motivo: {transfer.decisionReason}</p>
                          )}

                          {canDecide ? (
                            <div className="button-row">
                              <button
                                className="primary-button"
                                type="button"
                                onClick={() => approveTransfer(transfer.id, targetUser?.id)}
                              >
                                Aprovar
                              </button>
                              <button
                                className="secondary-button"
                                type="button"
                                onClick={() => rejectTransfer(transfer.id, targetUser?.id)}
                              >
                                Rejeitar
                              </button>
                            </div>
                          ) : (
                            <p className="empty-text">
                              {isPending
                                ? 'Aguardando a assinatura digital do usuário alvo.'
                                : 'Solicitação finalizada.'}
                            </p>
                          )}
                        </article>
                      );
                    })
                  )}
                </div>
              </section>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, tone }) {
  return (
    <article className={`stat-card tone-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </article>
  );
}

function SectionTitle({ title, subtitle }) {
  return (
    <div className="section-title">
      <h2>{title}</h2>
      <p>{subtitle}</p>
    </div>
  );
}

function SimpleTable({ rows, columns, onEdit, onDelete, extraActions }) {
  if (!rows || rows.length === 0) {
    return <p className="empty-text">Nenhum registro encontrado.</p>;
  }

  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column.label}>{column.label}</th>
            ))}
            {(onEdit || onDelete || extraActions) && <th>Ações</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id}>
              {columns.map((column) => (
                <td key={column.label}>{column.render ? column.render(row) : row[column.key]}</td>
              ))}
              {(onEdit || onDelete || extraActions) && (
                <td>
                  <div className="actions">
                    {onEdit && (
                      <button className="inline-button" type="button" onClick={() => onEdit(row)}>
                        Editar
                      </button>
                    )}
                    {extraActions && extraActions(row)}
                    {onDelete && (
                      <button className="inline-button danger" type="button" onClick={() => onDelete(row.id)}>
                        Excluir
                      </button>
                    )}
                  </div>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function EntityForm({ fields, values, onChange, onSubmit, submitLabel, onReset }) {
  return (
    <form className="form-grid" onSubmit={onSubmit}>
      {fields.map((field) => (
        field.type === 'checkbox' ? (
          <div className="field" key={field.name}>
            <label className="checkbox-field">
              <input
                type="checkbox"
                checked={Boolean(values[field.name])}
                onChange={(event) => onChange(field.name, event.target.checked)}
              />
              <span>{field.label}</span>
            </label>
          </div>
        ) : (
          <label className="field" key={field.name}>
            <span>{field.label}</span>
            {field.type === 'select' ? (
              <select
                value={values[field.name] ?? ''}
                onChange={(event) => onChange(field.name, event.target.value)}
                required={field.required}
              >
                <option value="">Selecione</option>
                {field.options.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            ) : field.type === 'textarea' ? (
              <textarea
                value={values[field.name] ?? ''}
                onChange={(event) => onChange(field.name, event.target.value)}
                rows={4}
                placeholder={field.placeholder}
                required={field.required}
              />
            ) : (
              <input
                type={field.type || 'text'}
                value={values[field.name] ?? ''}
                onChange={(event) => onChange(field.name, event.target.value)}
                placeholder={field.placeholder}
                required={field.required}
              />
            )}
          </label>
        )
      ))}

      <div className="button-row">
        <button className="primary-button" type="submit">
          {submitLabel}
        </button>
        <button className="secondary-button" type="button" onClick={onReset}>
          Limpar
        </button>
      </div>
    </form>
  );
}

function formatDateTime(value) {
  if (!value) {
    return '-';
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }
  return new Intl.DateTimeFormat('pt-BR', {
    dateStyle: 'short',
    timeStyle: 'short'
  }).format(date);
}

function toInputDateTime(value) {
  if (!value) {
    return '';
  }
  return String(value).slice(0, 16);
}

function statusClass(status) {
  switch (status) {
    case 'SCHEDULED':
      return 'scheduled';
    case 'CANCELLED':
      return 'cancelled';
    case 'COMPLETED':
      return 'completed';
    case 'TRANSFERRED':
      return 'transferred';
    case 'APPROVED':
      return 'approved';
    case 'REJECTED':
      return 'rejected';
    case 'PENDING':
      return 'pending';
    default:
      return 'neutral';
  }
}

export default App;
