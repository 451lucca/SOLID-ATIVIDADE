package com.labagenda.web;

import com.labagenda.domain.Laboratory;
import com.labagenda.service.LaboratoryService;
import com.labagenda.web.dto.LaboratoryRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/laboratories")
@Validated
public class LaboratoryController {

    private final LaboratoryService laboratoryService;

    public LaboratoryController(LaboratoryService laboratoryService) {
        this.laboratoryService = laboratoryService;
    }

    @GetMapping
    public List<Laboratory> list() {
        return laboratoryService.list();
    }

    @GetMapping("/{id}")
    public Laboratory get(@PathVariable Long id) {
        return laboratoryService.get(id);
    }

    @PostMapping
    public ResponseEntity<Laboratory> create(@Valid @RequestBody LaboratoryRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(laboratoryService.create(request));
    }

    @PutMapping("/{id}")
    public Laboratory update(@PathVariable Long id, @Valid @RequestBody LaboratoryRequest request) {
        return laboratoryService.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        laboratoryService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
