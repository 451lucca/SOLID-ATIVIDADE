package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class OrderFormatterTest {

    @Test
    void formatsOrderInformationForDisplay() {
        Order order = new Order(
            "order-2",
            "Ana",
            Collections.singletonList(new OrderItem("Refrigerante", 3, new BigDecimal("6.00"))),
            new BigDecimal("18.00"),
            LocalDateTime.of(2026, 5, 18, 11, 15)
        );

        String formatted = new OrderFormatter().format(order);

        assertTrue(formatted.contains("Order order-2"));
        assertTrue(formatted.contains("Customer: Ana"));
        assertTrue(formatted.contains("Refrigerante x3"));
        assertTrue(formatted.contains("Total: R$ 18.00"));
    }
}
