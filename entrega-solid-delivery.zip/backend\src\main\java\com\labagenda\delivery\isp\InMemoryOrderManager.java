package com.labagenda.delivery.isp;

import com.labagenda.delivery.srp.Order;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class InMemoryOrderManager implements OrderManager {

    private final Map<String, Order> orders = new LinkedHashMap<String, Order>();

    @Override
    public void register(Order order) {
        Order safeOrder = Objects.requireNonNull(order, "order");
        orders.put(safeOrder.getId(), safeOrder);
    }

    @Override
    public List<Order> listOrders() {
        return new ArrayList<Order>(orders.values());
    }
}
