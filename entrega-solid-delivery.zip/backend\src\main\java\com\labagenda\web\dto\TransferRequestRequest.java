package com.labagenda.web.dto;

import javax.validation.constraints.NotNull;

public class TransferRequestRequest {

    @NotNull(message = "é obrigatório")
    private Long reservationId;

    @NotNull(message = "é obrigatório")
    private Long requestedById;

    @NotNull(message = "é obrigatório")
    private Long targetUserId;

    private String message;

    public Long getReservationId() {
        return reservationId;
    }

    public void setReservationId(Long reservationId) {
        this.reservationId = reservationId;
    }

    public Long getRequestedById() {
        return requestedById;
    }

    public void setRequestedById(Long requestedById) {
        this.requestedById = requestedById;
    }

    public Long getTargetUserId() {
        return targetUserId;
    }

    public void setTargetUserId(Long targetUserId) {
        this.targetUserId = targetUserId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
