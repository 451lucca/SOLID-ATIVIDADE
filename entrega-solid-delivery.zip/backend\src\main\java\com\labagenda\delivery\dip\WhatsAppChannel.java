package com.labagenda.delivery.dip;

import java.util.Objects;

public class WhatsAppChannel extends AbstractNotificationChannel {

    private final String businessAccount;

    public WhatsAppChannel(String businessAccount) {
        String trimmed = Objects.requireNonNull(businessAccount, "businessAccount").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("businessAccount cannot be blank");
        }
        this.businessAccount = trimmed;
    }

    public String getBusinessAccount() {
        return businessAccount;
    }

    @Override
    public String getChannelName() {
        return "WhatsApp";
    }
}
