package com.labagenda.delivery.ocp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

abstract class AbstractPaymentMethod implements PaymentMethod {

    @Override
    public final PaymentReceipt pay(BigDecimal amount) {
        requirePositiveAmount(amount);
        return new PaymentReceipt(getMethodName(), amount, UUID.randomUUID().toString(), LocalDateTime.now());
    }

    private void requirePositiveAmount(BigDecimal amount) {
        if (amount == null) {
            throw new IllegalArgumentException("amount cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("amount must be greater than zero");
        }
    }
}
