package com.labagenda.delivery.isp;

public interface ReportGenerator {

    String generate();
}
