package com.labagenda.service;

import com.labagenda.domain.AppUser;
import com.labagenda.domain.Laboratory;
import com.labagenda.domain.Reservation;
import com.labagenda.domain.ReservationStatus;
import com.labagenda.domain.TransferRequest;
import com.labagenda.repository.AppUserRepository;
import com.labagenda.repository.LaboratoryRepository;
import com.labagenda.repository.ReservationRepository;
import com.labagenda.repository.TransferRequestRepository;
import com.labagenda.web.BusinessRuleException;
import com.labagenda.web.ResourceNotFoundException;
import com.labagenda.web.dto.ReservationRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ReservationService {

    private final ReservationRepository reservationRepository;
    private final LaboratoryRepository laboratoryRepository;
    private final AppUserRepository userRepository;
    private final TransferRequestRepository transferRequestRepository;

    public ReservationService(ReservationRepository reservationRepository,
                              LaboratoryRepository laboratoryRepository,
                              AppUserRepository userRepository,
                              TransferRequestRepository transferRequestRepository) {
        this.reservationRepository = reservationRepository;
        this.laboratoryRepository = laboratoryRepository;
        this.userRepository = userRepository;
        this.transferRequestRepository = transferRequestRepository;
    }

    @Transactional(readOnly = true)
    public List<Reservation> list(Long laboratoryId, Long reservedById) {
        List<Reservation> reservations = reservationRepository.findAll(Sort.by(Sort.Direction.ASC, "startAt"));
        return reservations.stream()
                .filter(reservation -> laboratoryId == null || reservation.getLaboratory().getId().equals(laboratoryId))
                .filter(reservation -> reservedById == null || reservation.getReservedBy().getId().equals(reservedById))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Reservation get(Long id) {
        return reservationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reserva não encontrada."));
    }

    public Reservation create(ReservationRequest request) {
        validateWindow(request.getStartAt(), request.getEndAt());
        Laboratory laboratory = resolveLaboratory(request.getLaboratoryId());
        AppUser user = resolveUser(request.getReservedById());
        ensureNoConflict(0L, laboratory.getId(), request.getStartAt(), request.getEndAt());

        Reservation reservation = new Reservation();
        apply(reservation, request);
        reservation.setLaboratory(laboratory);
        reservation.setReservedBy(user);
        reservation.setStatus(normalizeStatus(request.getStatus()));
        return reservationRepository.save(reservation);
    }

    public Reservation update(Long id, ReservationRequest request) {
        validateWindow(request.getStartAt(), request.getEndAt());
        Reservation reservation = get(id);
        Laboratory laboratory = resolveLaboratory(request.getLaboratoryId());
        AppUser user = resolveUser(request.getReservedById());
        ensureNoConflict(id, laboratory.getId(), request.getStartAt(), request.getEndAt());

        apply(reservation, request);
        reservation.setLaboratory(laboratory);
        reservation.setReservedBy(user);
        reservation.setStatus(normalizeStatus(request.getStatus()));
        return reservationRepository.save(reservation);
    }

    public void delete(Long id) {
        Reservation reservation = get(id);
        transferRequestRepository.deleteByReservationId(id);
        reservationRepository.delete(reservation);
    }

    public Reservation cancel(Long id) {
        Reservation reservation = get(id);
        reservation.setStatus(ReservationStatus.CANCELLED);
        return reservationRepository.save(reservation);
    }

    private void validateWindow(LocalDateTime startAt, LocalDateTime endAt) {
        if (startAt == null || endAt == null) {
            throw new BusinessRuleException("Informe o início e o fim da reserva.");
        }
        if (!startAt.isBefore(endAt)) {
            throw new BusinessRuleException("A data/hora inicial precisa ser anterior à final.");
        }
    }

    private void ensureNoConflict(Long reservationId, Long laboratoryId, LocalDateTime startAt, LocalDateTime endAt) {
        if (reservationRepository.hasTimeConflict(laboratoryId, reservationId, startAt, endAt)) {
            throw new BusinessRuleException("Já existe uma reserva nesse laboratório no período informado.");
        }
    }

    private Laboratory resolveLaboratory(Long laboratoryId) {
        return laboratoryRepository.findById(laboratoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratório não encontrado."));
    }

    private AppUser resolveUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado."));
    }

    private void apply(Reservation reservation, ReservationRequest request) {
        reservation.setTitle(normalize(request.getTitle()));
        reservation.setPurpose(normalize(request.getPurpose()));
        reservation.setStartAt(request.getStartAt());
        reservation.setEndAt(request.getEndAt());
        reservation.setNotes(normalize(request.getNotes()));
    }

    private ReservationStatus normalizeStatus(ReservationStatus status) {
        return status == null ? ReservationStatus.SCHEDULED : status;
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}
