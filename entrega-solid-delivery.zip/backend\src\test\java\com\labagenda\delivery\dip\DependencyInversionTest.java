package com.labagenda.delivery.dip;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DependencyInversionTest {

    @Test
    void usesEmailChannelThroughAbstraction() {
        EmailChannel channel = new EmailChannel("noreply@delivery.com");
        NotificationService service = new NotificationService(channel);

        service.send("cliente@exemplo.com", "Seu pedido saiu para entrega");

        assertEquals("Email", service.getChannelName());
        assertEquals("cliente@exemplo.com", channel.getLastRecipient());
        assertEquals("Seu pedido saiu para entrega", channel.getLastMessage());
    }

    @Test
    void usesSmsChannelThroughAbstraction() {
        SmsChannel channel = new SmsChannel("DELIVERY");
        NotificationService service = new NotificationService(channel);

        service.send("+5511999999999", "Pedido confirmado");

        assertEquals("SMS", service.getChannelName());
        assertEquals("+5511999999999", channel.getLastRecipient());
        assertEquals("Pedido confirmado", channel.getLastMessage());
    }

    @Test
    void usesWhatsAppChannelThroughAbstraction() {
        WhatsAppChannel channel = new WhatsAppChannel("delivery-bot");
        NotificationService service = new NotificationService(channel);

        service.send("+5511888888888", "Pedido entregue");

        assertEquals("WhatsApp", service.getChannelName());
        assertEquals("+5511888888888", channel.getLastRecipient());
        assertEquals("Pedido entregue", channel.getLastMessage());
    }
}
