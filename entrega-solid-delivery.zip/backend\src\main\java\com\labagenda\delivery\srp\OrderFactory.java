package com.labagenda.delivery.srp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class OrderFactory {

    public Order create(String customerName, List<OrderItem> items) {
        List<OrderItem> safeItems = Objects.requireNonNull(items, "items");
        if (safeItems.isEmpty()) {
            throw new IllegalArgumentException("items cannot be empty");
        }
        return new Order(UUID.randomUUID().toString(), customerName, safeItems, calculateTotal(safeItems), LocalDateTime.now());
    }

    private BigDecimal calculateTotal(List<OrderItem> items) {
        BigDecimal total = BigDecimal.ZERO;
        for (OrderItem item : items) {
            total = total.add(item.getSubtotal());
        }
        return total;
    }
}
