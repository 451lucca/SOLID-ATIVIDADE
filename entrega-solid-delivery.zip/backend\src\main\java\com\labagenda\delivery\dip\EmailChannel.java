package com.labagenda.delivery.dip;

import java.util.Objects;

public class EmailChannel extends AbstractNotificationChannel {

    private final String fromAddress;

    public EmailChannel(String fromAddress) {
        String trimmed = Objects.requireNonNull(fromAddress, "fromAddress").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("fromAddress cannot be blank");
        }
        this.fromAddress = trimmed;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    @Override
    public String getChannelName() {
        return "Email";
    }
}
