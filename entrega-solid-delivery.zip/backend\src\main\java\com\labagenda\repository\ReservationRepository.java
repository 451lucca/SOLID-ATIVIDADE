package com.labagenda.repository;

import com.labagenda.domain.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    List<Reservation> findByReservedByIdOrderByStartAtAsc(Long reservedById);

    List<Reservation> findByLaboratoryIdOrderByStartAtAsc(Long laboratoryId);

    long countByReservedById(Long reservedById);

    long countByLaboratoryId(Long laboratoryId);

    @Query("select case when count(r) > 0 then true else false end " +
            "from Reservation r " +
            "where r.laboratory.id = :laboratoryId " +
            "and r.id <> :reservationId " +
            "and r.status <> com.labagenda.domain.ReservationStatus.CANCELLED " +
            "and r.startAt < :endAt " +
            "and r.endAt > :startAt")
    boolean hasTimeConflict(@Param("laboratoryId") Long laboratoryId,
                            @Param("reservationId") Long reservationId,
                            @Param("startAt") LocalDateTime startAt,
                            @Param("endAt") LocalDateTime endAt);
}
