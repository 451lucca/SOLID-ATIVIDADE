package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.Objects;

public class Bebida extends Product {

    private final String type;
    private final int volumeMl;

    public Bebida(String type, int volumeMl, BigDecimal price) {
        super("Bebida " + requireText(type, "type"), price);
        this.type = requireText(type, "type");
        if (volumeMl <= 0) {
            throw new IllegalArgumentException("volumeMl must be greater than zero");
        }
        this.volumeMl = volumeMl;
    }

    public String getType() {
        return type;
    }

    public int getVolumeMl() {
        return volumeMl;
    }

    @Override
    public String getCategory() {
        return "Bebida";
    }

    private static String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
