package com.labagenda.delivery.ocp;

import java.util.Objects;

public class PixPaymentMethod extends AbstractPaymentMethod {

    private final String pixKey;

    public PixPaymentMethod(String pixKey) {
        String trimmed = Objects.requireNonNull(pixKey, "pixKey").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("pixKey cannot be blank");
        }
        this.pixKey = trimmed;
    }

    public String getPixKey() {
        return pixKey;
    }

    @Override
    public String getMethodName() {
        return "PIX";
    }
}
