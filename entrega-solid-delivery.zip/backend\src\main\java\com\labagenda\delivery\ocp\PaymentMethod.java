package com.labagenda.delivery.ocp;

import java.math.BigDecimal;

public interface PaymentMethod {

    String getMethodName();

    PaymentReceipt pay(BigDecimal amount);
}
