package com.labagenda.service;

import com.labagenda.domain.AppUser;
import com.labagenda.repository.AppUserRepository;
import com.labagenda.repository.ReservationRepository;
import com.labagenda.repository.TransferRequestRepository;
import com.labagenda.web.BusinessRuleException;
import com.labagenda.web.ResourceNotFoundException;
import com.labagenda.web.dto.UserRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Service
@Transactional
public class AppUserService {

    private final AppUserRepository userRepository;
    private final ReservationRepository reservationRepository;
    private final TransferRequestRepository transferRequestRepository;

    public AppUserService(AppUserRepository userRepository,
                          ReservationRepository reservationRepository,
                          TransferRequestRepository transferRequestRepository) {
        this.userRepository = userRepository;
        this.reservationRepository = reservationRepository;
        this.transferRequestRepository = transferRequestRepository;
    }

    @Transactional(readOnly = true)
    public List<AppUser> list() {
        return userRepository.findAll(Sort.by(Sort.Direction.ASC, "fullName"));
    }

    @Transactional(readOnly = true)
    public AppUser get(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado."));
    }

    public AppUser create(UserRequest request) {
        validateEmail(request.getEmail(), null);
        AppUser user = new AppUser();
        apply(user, request);
        return userRepository.save(user);
    }

    public AppUser update(Long id, UserRequest request) {
        AppUser user = get(id);
        validateEmail(request.getEmail(), id);
        apply(user, request);
        return userRepository.save(user);
    }

    public void delete(Long id) {
        AppUser user = get(id);
        if (reservationRepository.countByReservedById(id) > 0) {
            throw new BusinessRuleException("Não é possível excluir o usuário porque ele possui reservas vinculadas.");
        }
        if (transferRequestRepository.countByRequestedById(id) > 0 || transferRequestRepository.countByTargetUserId(id) > 0) {
            throw new BusinessRuleException("Não é possível excluir o usuário porque existem solicitações de troca vinculadas.");
        }
        userRepository.delete(user);
    }

    private void validateEmail(String email, Long ignoreId) {
        String normalizedEmail = normalize(email);
        Optional<AppUser> existing = userRepository.findByEmailIgnoreCase(normalizedEmail);
        if (existing.isPresent() && (ignoreId == null || !existing.get().getId().equals(ignoreId))) {
            throw new BusinessRuleException("Já existe um usuário cadastrado com esse email.");
        }
    }

    private void apply(AppUser user, UserRequest request) {
        user.setFullName(normalize(request.getFullName()));
        user.setEmail(normalize(request.getEmail()).toLowerCase(Locale.ROOT));
        user.setRole(request.getRole() == null ? user.getRole() : request.getRole());
        user.setActive(request.getActive() == null ? Boolean.TRUE : request.getActive());
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}
