package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

public class MenuTotalCalculator {

    public BigDecimal calculateTotal(List<Product> products) {
        List<Product> safeProducts = Objects.requireNonNull(products, "products");
        BigDecimal total = BigDecimal.ZERO;
        for (Product product : safeProducts) {
            total = total.add(product.getPrice());
        }
        return total;
    }
}
