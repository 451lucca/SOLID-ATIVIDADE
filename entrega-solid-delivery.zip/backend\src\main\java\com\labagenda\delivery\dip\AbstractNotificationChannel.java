package com.labagenda.delivery.dip;

import java.util.Objects;

abstract class AbstractNotificationChannel implements NotificationChannel {

    private String lastRecipient;
    private String lastMessage;

    @Override
    public final void send(String recipient, String message) {
        this.lastRecipient = requireText(recipient, "recipient");
        this.lastMessage = requireText(message, "message");
    }

    public String getLastRecipient() {
        return lastRecipient;
    }

    public String getLastMessage() {
        return lastMessage;
    }

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
