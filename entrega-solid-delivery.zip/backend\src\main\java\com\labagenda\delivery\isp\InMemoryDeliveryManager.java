package com.labagenda.delivery.isp;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public class InMemoryDeliveryManager implements DeliveryManager {

    private final Map<String, String> addresses = new LinkedHashMap<String, String>();
    private final Map<String, String> statusByOrderId = new LinkedHashMap<String, String>();

    @Override
    public void schedule(String orderId, String address) {
        String safeOrderId = requireText(orderId, "orderId");
        addresses.put(safeOrderId, requireText(address, "address"));
        statusByOrderId.put(safeOrderId, "SCHEDULED");
    }

    @Override
    public String getStatus(String orderId) {
        return statusByOrderId.get(requireText(orderId, "orderId"));
    }

    @Override
    public int countScheduled() {
        return statusByOrderId.size();
    }

    public String getAddress(String orderId) {
        return addresses.get(requireText(orderId, "orderId"));
    }

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
