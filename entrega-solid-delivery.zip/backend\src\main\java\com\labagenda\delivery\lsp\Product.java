package com.labagenda.delivery.lsp;

import java.math.BigDecimal;
import java.util.Objects;

public abstract class Product {

    private final String name;
    private final BigDecimal price;

    protected Product(String name, BigDecimal price) {
        this.name = requireText(name, "name");
        this.price = Objects.requireNonNull(price, "price");
        if (price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("price must be greater than zero");
        }
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public String describe() {
        return getCategory() + " - " + name + " - R$ " + price.toPlainString();
    }

    public abstract String getCategory();

    private String requireText(String value, String fieldName) {
        String trimmed = Objects.requireNonNull(value, fieldName).trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank");
        }
        return trimmed;
    }
}
