package com.labagenda.delivery.srp;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class InMemoryOrderRepository implements OrderRepository {

    private final Map<String, Order> storage = new LinkedHashMap<String, Order>();

    @Override
    public void save(Order order) {
        Order safeOrder = Objects.requireNonNull(order, "order");
        storage.put(safeOrder.getId(), safeOrder);
    }

    @Override
    public Optional<Order> findById(String orderId) {
        return Optional.ofNullable(storage.get(orderId));
    }

    @Override
    public List<Order> findAll() {
        return new ArrayList<Order>(storage.values());
    }
}
