package com.labagenda.delivery.dip;

import java.util.Objects;

public class NotificationService {

    private final NotificationChannel channel;

    public NotificationService(NotificationChannel channel) {
        this.channel = Objects.requireNonNull(channel, "channel");
    }

    public void send(String recipient, String message) {
        channel.send(recipient, message);
    }

    public String getChannelName() {
        return channel.getChannelName();
    }
}
