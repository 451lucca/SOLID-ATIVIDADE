package com.labagenda.service;

import com.labagenda.domain.AppUser;
import com.labagenda.domain.Reservation;
import com.labagenda.domain.ReservationStatus;
import com.labagenda.domain.TransferRequest;
import com.labagenda.domain.TransferStatus;
import com.labagenda.repository.AppUserRepository;
import com.labagenda.repository.ReservationRepository;
import com.labagenda.repository.TransferRequestRepository;
import com.labagenda.web.BusinessRuleException;
import com.labagenda.web.ResourceNotFoundException;
import com.labagenda.web.dto.TransferDecisionRequest;
import com.labagenda.web.dto.TransferRequestRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class TransferRequestService {

    private final TransferRequestRepository transferRequestRepository;
    private final ReservationRepository reservationRepository;
    private final AppUserRepository userRepository;

    public TransferRequestService(TransferRequestRepository transferRequestRepository,
                                  ReservationRepository reservationRepository,
                                  AppUserRepository userRepository) {
        this.transferRequestRepository = transferRequestRepository;
        this.reservationRepository = reservationRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public List<TransferRequest> list(TransferStatus status) {
        if (status != null) {
            return transferRequestRepository.findByStatusOrderByCreatedAtDesc(status);
        }
        return transferRequestRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    @Transactional(readOnly = true)
    public TransferRequest get(Long id) {
        return transferRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Solicitação de troca não encontrada."));
    }

    public TransferRequest create(TransferRequestRequest request) {
        Reservation reservation = resolveReservation(request.getReservationId());
        AppUser requestedBy = resolveUser(request.getRequestedById());
        AppUser targetUser = resolveUser(request.getTargetUserId());

        if (reservation.getStatus() == ReservationStatus.CANCELLED) {
            throw new BusinessRuleException("Não é possível criar solicitação de troca para uma reserva cancelada.");
        }
        if (!reservation.getReservedBy().getId().equals(requestedBy.getId())) {
            throw new BusinessRuleException("A solicitação de troca precisa ser criada pelo usuário que possui a reserva.");
        }
        if (requestedBy.getId().equals(targetUser.getId())) {
            throw new BusinessRuleException("O usuário solicitante e o usuário alvo precisam ser diferentes.");
        }
        if (transferRequestRepository.existsByReservationIdAndTargetUserIdAndStatus(reservation.getId(), targetUser.getId(), TransferStatus.PENDING)) {
            throw new BusinessRuleException("Já existe uma solicitação pendente para esse usuário e essa reserva.");
        }

        TransferRequest transferRequest = new TransferRequest();
        transferRequest.setReservation(reservation);
        transferRequest.setRequestedBy(requestedBy);
        transferRequest.setTargetUser(targetUser);
        transferRequest.setMessage(normalize(request.getMessage()));
        transferRequest.setStatus(TransferStatus.PENDING);
        return transferRequestRepository.save(transferRequest);
    }

    public TransferRequest approve(Long id, TransferDecisionRequest request) {
        TransferRequest transferRequest = get(id);
        ensurePending(transferRequest);
        ensureApprover(transferRequest, request.getApproverUserId());

        AppUser targetUser = transferRequest.getTargetUser();
        Reservation reservation = transferRequest.getReservation();
        reservation.setReservedBy(targetUser);
        reservation.setStatus(ReservationStatus.TRANSFERRED);
        reservationRepository.save(reservation);

        transferRequest.setStatus(TransferStatus.APPROVED);
        transferRequest.setDecidedAt(LocalDateTime.now());
        transferRequest.setDecisionReason(normalize(request.getReason()));
        return transferRequestRepository.save(transferRequest);
    }

    public TransferRequest reject(Long id, TransferDecisionRequest request) {
        TransferRequest transferRequest = get(id);
        ensurePending(transferRequest);
        ensureApprover(transferRequest, request.getApproverUserId());

        transferRequest.setStatus(TransferStatus.REJECTED);
        transferRequest.setDecidedAt(LocalDateTime.now());
        transferRequest.setDecisionReason(normalize(request.getReason()));
        return transferRequestRepository.save(transferRequest);
    }

    private void ensurePending(TransferRequest transferRequest) {
        if (transferRequest.getStatus() != TransferStatus.PENDING) {
            throw new BusinessRuleException("A solicitação já foi processada.");
        }
    }

    private void ensureApprover(TransferRequest transferRequest, Long approverUserId) {
        if (approverUserId == null) {
            throw new BusinessRuleException("Informe o usuário que está aprovando a solicitação.");
        }
        if (!transferRequest.getTargetUser().getId().equals(approverUserId)) {
            throw new BusinessRuleException("Somente o usuário alvo pode aprovar ou rejeitar essa troca.");
        }
    }

    private Reservation resolveReservation(Long reservationId) {
        return reservationRepository.findById(reservationId)
                .orElseThrow(() -> new ResourceNotFoundException("Reserva não encontrada."));
    }

    private AppUser resolveUser(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuário não encontrado."));
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}
