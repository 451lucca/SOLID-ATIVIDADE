package com.labagenda.delivery.ocp;

import java.util.Objects;

public class CardPaymentMethod extends AbstractPaymentMethod {

    private final String cardholderName;

    public CardPaymentMethod(String cardholderName) {
        String trimmed = Objects.requireNonNull(cardholderName, "cardholderName").trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("cardholderName cannot be blank");
        }
        this.cardholderName = trimmed;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    @Override
    public String getMethodName() {
        return "Card";
    }
}
