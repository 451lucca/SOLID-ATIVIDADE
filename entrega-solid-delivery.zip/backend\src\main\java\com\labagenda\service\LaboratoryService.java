package com.labagenda.service;

import com.labagenda.domain.Laboratory;
import com.labagenda.repository.LaboratoryRepository;
import com.labagenda.repository.ReservationRepository;
import com.labagenda.web.BusinessRuleException;
import com.labagenda.web.ResourceNotFoundException;
import com.labagenda.web.dto.LaboratoryRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class LaboratoryService {

    private final LaboratoryRepository laboratoryRepository;
    private final ReservationRepository reservationRepository;

    public LaboratoryService(LaboratoryRepository laboratoryRepository, ReservationRepository reservationRepository) {
        this.laboratoryRepository = laboratoryRepository;
        this.reservationRepository = reservationRepository;
    }

    @Transactional(readOnly = true)
    public List<Laboratory> list() {
        return laboratoryRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));
    }

    @Transactional(readOnly = true)
    public Laboratory get(Long id) {
        return laboratoryRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Laboratório não encontrado."));
    }

    public Laboratory create(LaboratoryRequest request) {
        Laboratory laboratory = new Laboratory();
        apply(laboratory, request);
        return laboratoryRepository.save(laboratory);
    }

    public Laboratory update(Long id, LaboratoryRequest request) {
        Laboratory laboratory = get(id);
        apply(laboratory, request);
        return laboratoryRepository.save(laboratory);
    }

    public void delete(Long id) {
        Laboratory laboratory = get(id);
        if (reservationRepository.countByLaboratoryId(id) > 0) {
            throw new BusinessRuleException("Não é possível excluir o laboratório porque existem reservas vinculadas.");
        }
        laboratoryRepository.delete(laboratory);
    }

    private void apply(Laboratory laboratory, LaboratoryRequest request) {
        laboratory.setName(normalize(request.getName()));
        laboratory.setDescription(normalize(request.getDescription()));
        laboratory.setLocation(normalize(request.getLocation()));
        laboratory.setCapacity(request.getCapacity() == null ? 1 : request.getCapacity());
        laboratory.setEquipment(normalize(request.getEquipment()));
        laboratory.setActive(request.getActive() == null ? Boolean.TRUE : request.getActive());
    }

    private String normalize(String value) {
        return value == null ? null : value.trim();
    }
}
