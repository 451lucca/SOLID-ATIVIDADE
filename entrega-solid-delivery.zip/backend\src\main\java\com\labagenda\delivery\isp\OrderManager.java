package com.labagenda.delivery.isp;

import com.labagenda.delivery.srp.Order;

import java.util.List;

public interface OrderManager {

    void register(Order order);

    List<Order> listOrders();
}
