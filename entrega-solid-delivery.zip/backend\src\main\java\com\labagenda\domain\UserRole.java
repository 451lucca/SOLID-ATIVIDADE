package com.labagenda.domain;

public enum UserRole {
    ADMIN,
    USER
}
